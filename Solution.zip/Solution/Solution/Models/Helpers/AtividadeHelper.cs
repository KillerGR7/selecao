﻿using System;
using System.Collections.Generic;
using System.IO;
using Solution.Models.Objetos;

namespace Solution.Models.Helpers
{
    public static class AtividadeHelper
    {
        /// <summary> Método que obtém a lista de palestras a partir do caminho de um arquivo proposals.txt </summary>
        /// <param name="caminho"> Caminho do arquio que contém as informações </param>
        /// <returns> List<Atividades>: Lista contendo as informações das atividades identificadas </Atividades></returns>
        public static List<Atividade> ObterPalestras(string caminho)
        {
            var lista = new List<Atividade>();
            using (var stmReader = new StreamReader(caminho))
            {
                string linha;
                // enquanto a linha do streamreader for diferente de nula.
                while ((linha = stmReader.ReadLine()) != null)
                {
                    var minutos = string.Join("", System.Text.RegularExpressions.Regex.Split(linha, @"[^\d]"));
                    var palestra = new Atividade();
                    palestra.Titulo = linha;
                    palestra.Minutos = !string.IsNullOrEmpty(minutos) ? Convert.ToInt32(minutos) : 0;
                    palestra.Horario = new DateTime();
                    lista.Add(palestra);
                }
            }
            return lista;
        }
    }
}