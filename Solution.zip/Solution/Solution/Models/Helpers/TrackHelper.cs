﻿using System.Collections.Generic;
using Solution.Models.Objetos;

namespace Solution.Models.Helpers
{
    public static class TrackHelper
    {
        /// <summary> Método construtor do Objeto Track </summary>
        /// <param name="nome"> Nome da nova Track </param>
        /// <returns> Track: Objeto com os valores inicializados </returns>
        public static Track NovaTrack(string nome)
        {
            return new Track
            {
                Nome = nome,
                Atividades = new List<Atividade>(),
                MinutosDisponiveisManha = 180,
                MinutosDisponiveisTarde = 240
            };
        }
    }
}