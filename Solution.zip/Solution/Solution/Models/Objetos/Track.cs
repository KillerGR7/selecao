﻿using System.Collections.Generic;

namespace Solution.Models.Objetos
{
    public class Track
    {
        public string Nome { get; set; }
        public List<Atividade> Atividades { get; set; }
        public int MinutosDisponiveisManha { get; set; }
        public int MinutosDisponiveisTarde { get; set; }
    }
}