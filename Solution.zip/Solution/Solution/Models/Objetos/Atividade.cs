﻿using System;

namespace Solution.Models.Objetos
{
    public class Atividade
    {
        public string Titulo { get; set; }
        public int Minutos { get; set; }
        public DateTime Horario { get; set; }
    }
}