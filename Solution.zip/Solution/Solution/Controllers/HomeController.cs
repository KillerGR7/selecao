﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Solution.Models.Helpers;
using Solution.Models.Objetos;

namespace Solution.Controllers
{
    public class HomeController : Controller
    {
        /// <summary> Retorna a página principal do sistema </summary>
        public ActionResult Index()
        {
            // Obtém a lista de atividades do arquivo
            var atividadesIdentificadas = AtividadeHelper.ObterPalestras(Server.MapPath("~/content/proposals.txt"));
            // Inicicaliza as variáveis
            var track1 = TrackHelper.NovaTrack("Track 1");
            var track2 = TrackHelper.NovaTrack("Track 2");
            var almoco = new Atividade { Titulo = "Almoço", Horario = new DateTime(2000, 01, 01, 12, 0, 0), Minutos = 60 };
            var networking = new Atividade { Titulo = "Evento de Networking", Horario = new DateTime(2000, 01, 01, 17, 0, 0), Minutos = 60 };
            var contadorHorasTrack1 = new DateTime(2000, 01, 01, 9, 0, 0);
            var contadorHorasTrack2 = new DateTime(2000, 01, 01, 9, 0, 0);
            // Cria a lista que recebe as atividades para adicionar após o almoço
            var addPosAlmoco = new List<Atividade>();

            // Realiza a organização das atividades com duração, de forma a encaixar nos horários disponíveis
            foreach (var atividade in atividadesIdentificadas.Where(a => a.Minutos > 0))
            {
                if (Encaixa(track1.MinutosDisponiveisManha, atividade.Minutos))
                {
                    track1.MinutosDisponiveisManha = track1.MinutosDisponiveisManha - atividade.Minutos;
                    atividade.Horario = contadorHorasTrack1;
                    track1.Atividades.Add(atividade);
                    contadorHorasTrack1 = contadorHorasTrack1.AddMinutes(atividade.Minutos);
                    if (track1.MinutosDisponiveisManha == 0)
                    {
                        contadorHorasTrack1 = contadorHorasTrack1.AddMinutes(almoco.Minutos);
                        track1.Atividades.Add(almoco);
                    }
                }
                else if (Encaixa(track1.MinutosDisponiveisTarde, atividade.Minutos))
                {
                    if (track1.MinutosDisponiveisManha > 29)
                    {
                        addPosAlmoco.Add(atividade);
                    }
                    else
                    {
                        track1.MinutosDisponiveisTarde = track1.MinutosDisponiveisTarde - atividade.Minutos;
                        atividade.Horario = contadorHorasTrack1;
                        track1.Atividades.Add(atividade);
                        contadorHorasTrack1 = contadorHorasTrack1.AddMinutes(atividade.Minutos);
                    }
                }
                else if (Encaixa(track2.MinutosDisponiveisManha, atividade.Minutos))
                {
                    track2.MinutosDisponiveisManha = track2.MinutosDisponiveisManha - atividade.Minutos;
                    atividade.Horario = contadorHorasTrack2;
                    track2.Atividades.Add(atividade);
                    contadorHorasTrack2 = contadorHorasTrack2.AddMinutes(atividade.Minutos);
                    if (track2.MinutosDisponiveisManha == 0)
                    {
                        contadorHorasTrack2 = contadorHorasTrack2.AddMinutes(almoco.Minutos);
                        track2.Atividades.Add(almoco);
                    }
                }
                else if (Encaixa(track2.MinutosDisponiveisTarde, atividade.Minutos))
                {
                    if (track2.MinutosDisponiveisManha > 29)
                    {
                        addPosAlmoco.Add(atividade);
                    }
                    else
                    {
                        track2.MinutosDisponiveisTarde = track2.MinutosDisponiveisTarde - atividade.Minutos;
                        atividade.Horario = contadorHorasTrack2;
                        track2.Atividades.Add(atividade);
                        contadorHorasTrack2 = contadorHorasTrack2.AddMinutes(atividade.Minutos);
                    }
                }
            }

            // Realiza a adição das atividades que ficaram para encaixe após o horário do almoço
            foreach (var atividade in addPosAlmoco)
            {
                if (track1.MinutosDisponiveisTarde >= atividade.Minutos)
                {
                    atividade.Horario = contadorHorasTrack1;
                    track1.Atividades.Add(atividade);
                    contadorHorasTrack1 = contadorHorasTrack1.AddMinutes(atividade.Minutos);
                }
                else if (track2.MinutosDisponiveisTarde >= atividade.Minutos)
                {
                    atividade.Horario = contadorHorasTrack2;
                    track2.Atividades.Add(atividade);
                    contadorHorasTrack2 = contadorHorasTrack2.AddMinutes(atividade.Minutos);
                }
            }
            
            // Atividades sem tempo de duração especificados são encaixadas nos horários disponíveis
            foreach (var atividade in atividadesIdentificadas.Where(a => a.Minutos == 0))
            {
                if (track1.MinutosDisponiveisManha > 0 || track1.MinutosDisponiveisTarde > 0)
                {
                    atividade.Horario = contadorHorasTrack1;
                    track1.Atividades.Add(atividade);
                }
                else if (track2.MinutosDisponiveisManha > 0 || track2.MinutosDisponiveisTarde > 0)
                {
                    atividade.Horario = contadorHorasTrack2;
                    track2.Atividades.Add(atividade);
                }
            }
            
            // Adiciona os eventos de Networking às listas de atividades
            track1.Atividades.Add(networking);
            track2.Atividades.Add(networking);
            // Seta os valores para as views
            ViewBag.Track1 = track1;
            ViewBag.Track2 = track2;
            return View();
        }

        /// <summary> Método para avaliação se uma atividade cabe no tempo disponível </summary>
        /// <param name="disponivel"> Quantidade de minutos disponíveis </param>
        /// <param name="duracao"> Minutos de duração da atividade</param>
        /// <returns> bool: Encaixa ou não </returns>
        public static bool Encaixa(int disponivel, int duracao)
        {
            return disponivel >= duracao && ((disponivel - duracao) > 29 || (disponivel - duracao) == 0);
        }
    }
}